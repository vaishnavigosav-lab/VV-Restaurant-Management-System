VV RESTAURANT - INFINITYFREE DEPLOYMENT

1. Upload the CONTENTS of this ZIP directly into /htdocs (not inside a nested folder).
2. Open config.php and replace PUT_YOUR_NEW_MYSQL_PASSWORD_HERE with your NEW MySQL password. Do not share it. Save.
3. In InfinityFree phpMyAdmin, select if0_43275381_vvrestaurant, choose Import, and import database.sql. The SQL is prepared to import into the selected database.
4. Open https://vvrestaurant.infinityfree.io/ and refresh with Ctrl+F5.

Important: If you already imported database.sql successfully, do not import it again unless you are comfortable with possible duplicate-data errors.
Default demo login after a fresh import: admin / admin123. Change this password after setup.

If a blank page remains, check PHP error logs / hosting control panel. Never enable public error display permanently.
