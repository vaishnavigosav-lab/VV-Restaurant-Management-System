VV RESTAURANT MANAGEMENT SYSTEM - TYBCA
Technology: PHP 8+, MySQL, HTML, CSS, JavaScript; designed for XAMPP.

FEATURES
- VV Restaurant luxury-style responsive landing page with a professional restaurant background and menu.
- Customer checkout without requiring login; customer details are stored in MySQL.
- Order types: Dine-in, Takeaway, Home Delivery.
- Customer name, phone, email; delivery address for home delivery; optional special instructions.
- Multiple food items/quantities in one order with live total calculation.
- Payment choices: Cash, UPI, Credit/Debit Card (demo records the choice only; no real payment gateway).
- Admin dashboard, menu management, order status management and sales report retained.
- Customer login/order page retained for the original demo flow.

SETUP (XAMPP)
1. Extract this ZIP into C:\xampp\htdocs\
2. Start Apache and MySQL in XAMPP Control Panel.
3. Open http://localhost/phpmyadmin/
4. Import restaurant_management/database.sql. This creates restaurant_db and sample data.
   If restaurant_db already exists, back up your data before importing; the SQL creates tables and sample records.
5. Open http://localhost/Restaurant_Management_System_TYBCA_Project/restaurant_management/

DEMO CREDENTIALS
Admin: username admin / password admin123
Customer: email customer@example.com / password customer123

IMPORTANT
- The PHP website cannot run by opening a PHP file directly; run it with XAMPP or another PHP/MySQL server.
- Home page photography and Google Fonts load from the internet.
- UPI/Card are demonstration choices only; no real payment is charged. A payment gateway is needed for real transactions.
- Demo passwords are plain text to remain compatible with the original starter project. This is for academic/local demonstration only, not production deployment.
