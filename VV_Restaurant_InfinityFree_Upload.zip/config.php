<?php
// Enter your InfinityFree MySQL password below. Never share it publicly.
$host = "sql211.infinityfree.com";
$user = "if0_43275381";
$pass = "PUT_YOUR_NEW_MYSQL_PASSWORD_HERE";
$db = "if0_43275381_vvrestaurant";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    error_log("Database connection failed: " . $conn->connect_error);
    http_response_code(500);
    exit("Database connection failed. Check your hosting database settings.");
}
$conn->set_charset("utf8mb4");
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
